# Kingdom Clicker (alpha)

Lightweight, headless-friendly kingdom builder with an optional Tk UI. Run `python -m build` to package or `python kclicker.py` to play.
